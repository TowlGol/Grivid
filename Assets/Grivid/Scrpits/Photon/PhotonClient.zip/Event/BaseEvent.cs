﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;
using ExitGames.Client.Photon;

#region 脚本用途
/// <summary>
/// SyncOffLineRequest
/// @ 创建人：刘亚鹏
/// @ 创建时间：2022/6/14 8:42:15
/// @ 作用:
///     Event基类
///     
///     
///     
/// </summary>
#endregion
public abstract class BaseEvent : MonoBehaviour
{
    public EventCode EventCode;
    public abstract void OnEvent(EventData eventData);

    public virtual void Start()
    {
        PhotonClient.Instance.AddEvent(this);
    }

    public void OnDestroy()
    {
        PhotonClient.Instance.RemoveEvent(this);
    }
}