﻿
using Common;
using ExitGames.Client.Photon;
using UnityEngine;


#region 项目概述
/// <summary>
/// SyncGraphEvent
/// @ 创建人：刘亚鹏
/// @ 创建时间：2022/10/6 9:20:13
/// @ 作用:
///     
///     
///     
///     
/// </summary>
#endregion

class SelectedEvent : BaseEvent
{
    string name;
    int type;
    Vector3 localCondition;
    GameObject chart;
    public override void OnEvent(EventData eventData)
    {
        float x, y, z;
        name =  (string)DictTool.GetValue(eventData.Parameters, (byte)0);
        x = (float)DictTool.GetValue(eventData.Parameters, (byte)10);
        y = (float)DictTool.GetValue(eventData.Parameters, (byte)11);
        z = (float)DictTool.GetValue(eventData.Parameters, (byte)12);
        localCondition = (Vector3)DictTool.GetValue(eventData.Parameters, (byte)1);
        type = (int)DictTool.GetValue(eventData.Parameters, (byte)2);
        chart = GameObject.Find(name);

        if (name == "chart") {
            PhoneControl(eventData);
        }
        else if(name == "camera") {
           if(type == 0) {
                chart.transform.localPosition = localCondition;
            }
           else if(type == 1) {
                chart.transform.localEulerAngles = localCondition;
            }
            else {
                chart.transform.localScale = localCondition;
            }
        }

        
    }
    private void PhoneControl(EventData eventData) {
        string cateGory = (string)DictTool.GetValue(eventData.Parameters, (byte)ParameterCode.cageGory);
        if (cateGory == "up") {
            chart.transform.localEulerAngles += new Vector3(5f, 0, 0);
        }
        else if (cateGory == "down") {
            chart.transform.localEulerAngles -= new Vector3(5f, 0, 0);
        }
        else if (cateGory == "left") {
            chart.transform.localEulerAngles += new Vector3(0, 5f, 0);
        }
        else if (cateGory == "right") {
            chart.transform.localEulerAngles -= new Vector3(0, 5f, 0);
        }
        else if (cateGory == "big") {
            chart.transform.localScale += new Vector3(0.1f, 0.1f, 0.1f);
        }
        else if (cateGory == "small") {
            chart.transform.localScale -= new Vector3(0.1f, 0.1f, 0.1f);
        }
    }
}
