﻿using Common;
using UnityEngine;
using ExitGames.Client.Photon;
#region 脚本用途
/// <summary>
/// SyncOffLineRequest
/// @ 创建人：刘亚鹏
/// @ 创建时间：2022/6/14 8:42:15
/// @ 作用:
///     请求基类
///     
///     
///     
/// </summary>
#endregion
public abstract class Request : MonoBehaviour
{
    public OperationCode OpCode;

    public abstract void DefaultRequest(GameObject go);
    public abstract void OnOperationResponse(OperationResponse response);

    public virtual void Start()
    {
        PhotonClient.Instance.AddRequest(this);
    }

    public void OnDestroy()
    {
        PhotonClient.Instance.RemoveRequest(this);
    }
}