﻿
using UnityEngine;
using Common;
using ExitGames.Client.Photon;
using System.Collections.Generic;

#region 项目概述
/// <summary>
/// TransGraph
/// @ 创建人：刘亚鹏
/// @ 创建时间：2022/10/5 15:15:46
/// @ 作用:
///     
///     
///     
///     
/// </summary>
#endregion
namespace Assets.Scripts
{
    class SelectedRequest : Request
    {
        public static SelectedRequest Instance;
        public SelectedRequest()
        {
            Instance = this;
        }

        public override void Start()
        {
            base.Start();
        }
       

        public void SendSelectCategory(string Category,string ChartName)
        {
            Dictionary<byte, object> data = new Dictionary<byte, object>();
            data.Add((byte)0, ChartName);
            data.Add((byte)ParameterCode.cageGory, Category);
            
            /* 发送数据*/
            PhotonClient.Peer.OpCustom((byte)OpCode, data, true);
            data.Clear();
            Debug.Log("发送成功");
        }

        public void SyncChartCondition(string ChartName,int type,float x, float y, float z ) {
            Dictionary<byte, object> data = new Dictionary<byte, object>();
            data.Add(0, ChartName);
            data.Add(2, type);
            data.Add(10, x);
            data.Add(11, y);
            data.Add(12, z);
            PhotonClient.Peer.OpCustom((byte)OpCode, data, true);
            data.Clear();
            Debug.Log("发送成功");

        }

        public override void DefaultRequest(GameObject go)
        {
        }

        public override void OnOperationResponse(OperationResponse response)
        {
        }
    }
}
