﻿using Assets.Scripts;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SyncChartCondition : MonoBehaviour
{
    private Vector3 localPosition { get; set; }
    private Vector3 localAngle { get; set; }
    private Vector3 localScale { get; set; }
    public float distance = 0.1f;
    private void Start() {
        localPosition = transform.localPosition;
        localAngle = transform.localEulerAngles;
        localScale = transform.localScale;
    }
    // Update is called once per frame
    void Update()
    {
        if (Vector3.Distance(localPosition, transform.localPosition) > distance) {
            SelectedRequest.Instance.SyncChartCondition(this.name, 0, localPosition.x,localPosition.y,localPosition.z);
            localPosition = transform.localPosition;
        }
        if (Vector3.Distance(localAngle, transform.localEulerAngles) > distance) {
            SelectedRequest.Instance.SyncChartCondition(this.name, 1, localAngle.x,localAngle.y,localAngle.z);
            localAngle = transform.localEulerAngles;
        }
        if (Vector3.Distance(localScale, transform.localScale) > distance) {
            SelectedRequest.Instance.SyncChartCondition(this.name, 2,localScale.x, localScale.y, localScale.z);
            localScale = transform.localScale;
        }
    }
}
